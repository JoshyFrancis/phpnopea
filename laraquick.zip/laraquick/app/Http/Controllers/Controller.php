<?php
namespace App\Http\Controllers;
class Controller{
	public function middleware(){
		return $this;
	}
	public function except(){
	}
}
