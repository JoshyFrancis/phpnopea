<?php
namespace Illuminate\Http;
class Request extends \Request{
	/*
	function __construct(\Request $request)  {
		$this->request  = $request->request;
		$this->files    = $request->files;
		$this->cookies  = $request->cookies;
		$this->session  = $request->session;
		$this->headers  = $request->headers;
	}
	*/
}
